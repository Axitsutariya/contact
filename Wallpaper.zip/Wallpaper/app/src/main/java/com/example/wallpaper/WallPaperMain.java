package com.example.wallpaper;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.permissionx.guolindev.PermissionX;
import com.permissionx.guolindev.callback.RequestCallback;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class WallPaperMain extends AppCompatActivity implements WallPaperAdapter.Myclick {

    RecyclerView recyclerView;
    String category;
    ArrayList<WallpaperItem> wallpaperItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wallpaper_main);
        getSupportActionBar().hide();

        recyclerView = findViewById(R.id.rv1);

//        category = getIntent().getExtras().getString("cat");

        category = App.getcategory();

        permitionruntime();

        if (category.equalsIgnoreCase("Love")) {
            wallpaperItems.add(new WallpaperItem("https://wallpapercave.com/dwp1x/wp8925550.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/astronaut_with_astronaus-974.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/you_asked_for_moon-949.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/my_first_love-948.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/me-and-you-forever-850.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper39-558.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/Hoodie-Guy-with-Heart-505.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper_14-368.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/romantic_love-383.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/affection-art-backlit-556662-54.jpg"));
        }

        if (category.equalsIgnoreCase("Flower")) {
            wallpaperItems.add(new WallpaperItem("https://wallpapercave.com/dwp1x/wp11087681.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/flower_wallpaper-826.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper430-811.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper408-805.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper394-795.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper370-790.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper273-757.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper_(4)-184.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper61-533.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/watercolor-flower-hd_4k_mobile_wallpaper_photo-314.jpg"));
        }
        if (category.equalsIgnoreCase("Nature")) {
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/desert_mountains_countryside_arid_land-1021.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/sunrise_in_swedish_lapland-1020.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/nature_wallpaper2-1017.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/giordano_rossoni-1013.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/nature_mobile_wallpaper-983.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/nature_mobile_wallpaper-985.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/alberta_lake_wide-898.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper381-798.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper228-731.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper239-736.jpg"));
        }
        if (category.equalsIgnoreCase("Joker")) {
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/736x/16/61/dd/1661ddea9bcc48265580dcc5ee6374d5.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/joker_and_harley-979.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/joker_gotham-977.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/john_wick-976.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/joker_walking_art-951.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper__1-471.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper__31-474.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper_13-436.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_walllpaper_297-424.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper_124-444.jpg"));
        }
        if (category.equalsIgnoreCase("Attitude")) {
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/neon_city-944.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/warrior_companion-906.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/secret_agent-905.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper122-650.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper107-638.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper118-648.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper23-545.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper43-528.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper21-563.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper105-381.jpg"));
        }
        if (category.equalsIgnoreCase("Car")) {
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/4a/fc/7a/4afc7a825ddde3560e3f4968949955c6.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/c9/dd/0c/c9dd0c0f6fb4f4009f33309f939e1ab2.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/3e/0d/88/3e0d884c09864e3daa89fca9b7467f96.jpg"));
            wallpaperItems.add(new WallpaperItem("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZM3oL7u8Z6yOiRhY7CgehMra-UR9vikQmlA&usqp=CAU"));
            wallpaperItems.add(new WallpaperItem("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2NWvpDVy-6RcsJovyM_Uu8Y9F38Gsbsfz5g&usqp=CAU"));
            wallpaperItems.add(new WallpaperItem("https://newevolutiondesigns.com/images/freebies/4k-car-iphone-wallpaper-3.jpg"));
            wallpaperItems.add(new WallpaperItem("https://images-na.ssl-images-amazon.com/images/I/61Fx7ABklrL.jpg"));
            wallpaperItems.add(new WallpaperItem("https://w0.peakpx.com/wallpaper/503/803/HD-wallpaper-sports-car-car-black-street.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper268-756.jpg"));
            wallpaperItems.add(new WallpaperItem("https://images-na.ssl-images-amazon.com/images/I/91TQJKqraSL.png"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/736x/82/41/1c/82411cae581f6008c075b70a4a7e4ad3.jpg"));
            wallpaperItems.add(new WallpaperItem("https://images-na.ssl-images-amazon.com/images/I/61Fx7ABklrL.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper101-633.jpg"));
        }
        if (category.equalsIgnoreCase("Radha Krishna")) {
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper159-690.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper93-637.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper_3-489.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/Cute_Radha_Krishna-155.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/Magical_Krishna-156.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper145-664.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/MOBILE_WALLPAPER422-813.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/originals/6c/d7/ff/6cd7ff1b423c8360f7e114931337144e.jpg"));
            wallpaperItems.add(new WallpaperItem("https://durgaimage.com/wp-content/uploads/2021/02/Wallpaper-Radha-Krishna-1200x2133.jpg"));
            wallpaperItems.add(new WallpaperItem("https://www.photosbin.com/uploads/o4l018012020113059.jpg"));
        }
        if (category.equalsIgnoreCase("beautiful")) {
            wallpaperItems.add(new WallpaperItem("https://cdn.statusqueen.com/mobilewallpaper/thumbnail/Masked-Girl-Neon-World-iPhone-Wallpaper-506.jpg"));
            wallpaperItems.add(new WallpaperItem("https://cdn.pixabay.com/photo/2017/12/27/09/38/abstract-3042277__340.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/736x/c2/bf/74/c2bf74d9ef43bf24dcf73cde5a24f61c.jpg"));
            wallpaperItems.add(new WallpaperItem("https://t3.ftcdn.net/jpg/04/55/59/16/360_F_455591600_jXwrIQX4lRcXtY1vJkTGZc9FuqxG5RYR.jpg"));
            wallpaperItems.add(new WallpaperItem("https://archziner.com/wp-content/uploads/2019/05/blue-purple-pink-turquoise-smoke-girly-iphone-wallpaper.jpg"));
            wallpaperItems.add(new WallpaperItem("https://mobwallpapershd.com/wp-content/uploads/2022/07/4k-Full-Cute-Wallpaper.jpg"));
            wallpaperItems.add(new WallpaperItem("https://myandroidwalls.com/wp-content/uploads/2022/07/Cute-Cartoon-Girl-Wallpaper.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/736x/ae/09/80/ae09805923b8a6760837538e61d5dd12.jpg"));
            wallpaperItems.add(new WallpaperItem("https://mobwallpapershd.com/wp-content/uploads/2021/08/HD-Anime-Girl-Mobile-Wallpaper.jpg"));
            wallpaperItems.add(new WallpaperItem("https://mobwallpapershd.com/wp-content/uploads/2021/08/4k-Anime-Girl-Android-Wallpaper-768x1365.jpg"));
        }
        if (category.equalsIgnoreCase("Classic")) {
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/c6/35/fd/c635fda8057d52c335cc55b5e22e2105.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/2f/66/15/2f6615d7ad755d18cd8de9afbe19ba69.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/a6/97/41/a6974142e2fa04b4a44620fda8901510.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/82/8d/64/828d6408883af5c1175999cefaddccee.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/b2/19/ac/b219acdbbd8a6e8fbc1eb140a2271832.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/5c/da/c5/5cdac550e24d8ecf9f18d2934f2d1b2e.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/35/3a/eb/353aeb8e291d56d3ef143b24bb0ddb39.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/53/ed/38/53ed38a0e508745f50f14363beffc562.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/52/4e/83/524e8320a88ba4952a8b49e8703edd70.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/63/a0/75/63a0758712539e8d412411cdf4a2f39c.jpg"));
        }
        if (category.equalsIgnoreCase("Floral")) {
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/23/92/9f/23929f7b46e4c3ecc1f1635dbab6c644.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/3b/e4/96/3be49645459bdbf3e4d768d632f25e68.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/e9/49/a6/e949a6a2dc85c10f88262d06ebef2b61.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/ba/b9/cb/bab9cbcfd276b0f0373a514dc94b1cd3.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/736x/63/b1/12/63b1124cdc05454f9b0f8e09a6ea6cad.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/95/40/fb/9540fb0d55245b1d7d60cbcae1da6e3e.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/90/08/72/900872a4c0d74e9385608499c7680326.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/b4/fb/14/b4fb143e5ce02d8588b231c04d09798e.jpg"));
        }
        if (category.equalsIgnoreCase("bike")) {
            wallpaperItems.add(new WallpaperItem("https://wallpapercave.com/wp/wp4307456.jpg"));
            wallpaperItems.add(new WallpaperItem("https://wallpapercave.com/dwp1x/wp10798431.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/2c/b7/c9/2cb7c93ec94d89bbf4aa3be9c249a5e8.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/34/94/79/3494790af82b6065d50bb2e6bb75b31c.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/e1/b7/7d/e1b77d8536e0d5b258b3771dec28f461.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/b4/cd/b3/b4cdb30aac9b9143e3bf307cbfe7fdec.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/a3/3c/f7/a33cf749fad937286dc34cb021aa77ad.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/47/aa/41/47aa419bdbdb5dcd6b3daec36a96869b.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/50/53/71/50537132025e2053c764b5c646f2ca5a.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/d0/3d/02/d03d0297f75a00611270b76a36527fe3.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/fc/d9/28/fcd928a2a2b555616af725b6af7d6d35.jpg"));
            wallpaperItems.add(new WallpaperItem("https://i.pinimg.com/236x/f5/4c/6f/f54c6f4c7017b6155d5929abfa7aeba8.jpg"));

        }

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(gridLayoutManager);

        WallPaperAdapter wallPaperAdapter = new WallPaperAdapter(wallpaperItems, WallPaperMain.this, WallPaperMain.this);
        recyclerView.setAdapter(wallPaperAdapter);


    }

    @Override
    public void getpos(int pos) {
        category = wallpaperItems.get(pos).getImage();
        App.setMylist(wallpaperItems);
        App.setimage(category);
        App.setpos(pos);
        Intent intent = new Intent(WallPaperMain.this, ViewPagerMain.class);
        startActivity(intent);
    }

    public void permitionruntime() {
        PermissionX.init(this)
                .permissions(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE)
                .request(new RequestCallback() {
                    @Override
                    public void onResult(boolean allGranted, @NonNull List<String> grantedList, @NonNull List<String> deniedList) {

                    }
                });

    }
}
