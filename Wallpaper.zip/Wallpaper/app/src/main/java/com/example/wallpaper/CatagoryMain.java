package com.example.wallpaper;

import android.app.Activity;
import android.app.SearchManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.example.wallpaper.databinding.CatagoryMainBinding;

import java.lang.reflect.AccessibleObject;
import java.util.ArrayList;
import java.util.Collections;

public class CatagoryMain extends AppCompatActivity implements CatagoryAdapter.Myclick {


    CatagoryMainBinding catagoryMainBinding;

    ArrayList<CatagoryItem> catagoryItems = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        catagoryMainBinding = CatagoryMainBinding.inflate(getLayoutInflater());
        setContentView(catagoryMainBinding.getRoot());



        registerNetworkBroadcastForNougat();
        LocalBroadcastManager.getInstance(this).registerReceiver(mMessageReceiver,
                new IntentFilter("custom-event-name"));

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        catagoryMainBinding.lv.setLayoutManager(linearLayoutManager);

        catagoryItems.add(new CatagoryItem("Love", "https://i.pinimg.com/736x/46/e7/2f/46e72fd14c8d799ca3d6ad5436f8dd3c.jpg"));
        catagoryItems.add(new CatagoryItem("Flower", "https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper59-574.jpg"));
        catagoryItems.add(new CatagoryItem("Nature", "https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper382-793.jpg"));
        catagoryItems.add(new CatagoryItem("Joker", "https://cdn.statusqueen.com/mobilewallpaper/thumbnail/joker_walking_alone-917.jpg"));
        catagoryItems.add(new CatagoryItem("Attitude", "https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mask_boy_with_slugger-904.jpg"));
        catagoryItems.add(new CatagoryItem("Car", "https://is5-ssl.mzstatic.com/image/thumb/Purple112/v4/94/f1/95/94f19554-4b3c-d768-6a12-16c3e39f832d/7694af01-8860-463b-bda2-77adeedabe1b_3.jpg/750x750bb.jpeg"));
        catagoryItems.add(new CatagoryItem("Radha Krishna", "https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper159-690.jpg"));
        catagoryItems.add(new CatagoryItem("beautiful", "https://cdn.statusqueen.com/mobilewallpaper/thumbnail/mobile_wallpaper_2-399.jpg"));
        catagoryItems.add(new CatagoryItem("Classic", "https://i.pinimg.com/236x/64/f7/05/64f7051a4bcc8098f0aae03a5388589a.jpg"));
        catagoryItems.add(new CatagoryItem("Floral", "https://i.pinimg.com/236x/23/92/9f/23929f7b46e4c3ecc1f1635dbab6c644.jpg"));
        catagoryItems.add(new CatagoryItem("bike", "https://i.pinimg.com/236x/6b/5a/ba/6b5abaf94714a4c5a80a2b967c0e8191.jpg"));

        CatagoryAdapter catagoryAdapter = new CatagoryAdapter(catagoryItems, CatagoryMain.this, CatagoryMain.this);
        catagoryMainBinding.lv.setAdapter(catagoryAdapter);

    }

    CatagoryAdapter catagoryAdapter;


    private boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
    }

    private void registerNetworkBroadcastForNougat() {
        registerReceiver(new NetCheckReciver(), new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
    }

    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String message = intent.getStringExtra("message");

            if (message.equalsIgnoreCase("on")) {

                catagoryMainBinding.data.setVisibility(View.VISIBLE);
                catagoryMainBinding.nodata.setVisibility(View.GONE);
            } else {
                catagoryMainBinding.data.setVisibility(View.GONE);
                catagoryMainBinding.nodata.setVisibility(View.VISIBLE);
            }


        }
    };


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.home_menu, menu);

        SearchManager manager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);

        SearchView search = (SearchView) menu.findItem(R.id.search).getActionView();

        search.setSearchableInfo(manager.getSearchableInfo(getComponentName()));

        search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {

                Log.d("TAG", "onQueryTextSubmit: "+query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {


                Log.d("TAG", "onQueryTextChange: "+newText);

                catagoryAdapter.filter(newText);
                catagoryAdapter.notifyDataSetChanged();

                return false;

            }

        });

        return super.onCreateOptionsMenu(menu);

    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {


        if (item.getItemId() == R.id.download) {
            Toast.makeText(this, "Download", Toast.LENGTH_SHORT).show();
        }
        if (item.getItemId() == R.id.setting) {
            Intent intent = new Intent(CatagoryMain.this, SettingActivity.class);
            startActivity(intent);
        }


        return super.onOptionsItemSelected(item);
    }


    @Override
    public void name_click(int pos) {

        String name = catagoryItems.get(pos).getName();
        Toast.makeText(this, "" + name, Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(CatagoryMain.this, WallPaperMain.class);
        App.setcategory(name);
        startActivity(intent);

    }
}
