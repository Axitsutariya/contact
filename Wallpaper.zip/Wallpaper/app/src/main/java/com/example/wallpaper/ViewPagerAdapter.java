package com.example.wallpaper;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class ViewPagerAdapter extends PagerAdapter {


    ArrayList<WallpaperItem>wallpaperItems;
    Context context;

    public ViewPagerAdapter(ArrayList<WallpaperItem> wallpaperItems, Context context) {
        this.wallpaperItems = wallpaperItems;
        this.context = context;
    }

    @Override
    public int getCount() {
        return wallpaperItems.size();
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {


        LayoutInflater inflater = LayoutInflater.from(context);
        ViewGroup layout = (ViewGroup) inflater.inflate(R.layout.item_viewpager,
                container, false);

        ImageView viewiv = layout.findViewById(R.id.viewiv);

        viewiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                App.setimage(wallpaperItems.get(position).getImage());
                App.setMylist(wallpaperItems);
                App.setpos(position);
                Intent intent = new Intent(context, ShowActivity.class);
                context.startActivity(intent);



            }
        });

        Glide.with(context).load(wallpaperItems.get(position).getImage()).into(viewiv);
        container.addView(layout);
        return layout;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

}
