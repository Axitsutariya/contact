package com.example.wallpaper;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.Locale;

public class CatagoryAdapter  extends RecyclerView.Adapter<CatagoryAdapter.Myh>{



    ArrayList<CatagoryItem> catagoryItems;
    Context context;
    Myclick myclick;
    ArrayList<CatagoryItem> temcatagoryItems;

    public CatagoryAdapter(ArrayList<CatagoryItem> catagoryItems, Context context, Myclick myclick) {
        this.catagoryItems = catagoryItems;
        this.context = context;
        this.myclick = myclick;
        temcatagoryItems=new ArrayList<>();
        temcatagoryItems.addAll(catagoryItems);
    }

    @NonNull
    @Override
    public Myh onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.item_catagory, parent, false);
        return new Myh(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Myh holder, int position) {

        holder.tv.setText(catagoryItems.get(position).getName());

        Glide.with(context).load(catagoryItems.get(position).getPath()).into(holder.siv);

        holder.tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myclick.name_click(position);
            }
        });

    }

    @Override
    public int getItemCount() {
        return catagoryItems.size();
    }

    public class Myh extends RecyclerView.ViewHolder {

        TextView tv;
        ImageView siv;


        public Myh(@NonNull View itemView) {
            super(itemView);

            tv = itemView.findViewById(R.id.tv);
            siv = itemView.findViewById(R.id.siv);



        }
    }

    public interface Myclick {

        public void name_click(int pos);
    }

    public void filter(String query){

        query=query.toLowerCase(Locale.ROOT);
        catagoryItems.clear();

        if (query.length()== 0) {
            catagoryItems.addAll(temcatagoryItems);

        }else{
            for (CatagoryItem temcatagoryItem : temcatagoryItems){

                if (temcatagoryItem.getName().toLowerCase(Locale.ROOT).contains(query)) {
                    catagoryItems.add(temcatagoryItem);
                }
            }
        }

        notifyDataSetChanged();
    }

}
