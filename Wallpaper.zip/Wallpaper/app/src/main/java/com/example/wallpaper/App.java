package com.example.wallpaper;

import android.app.Application;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;

public class App extends Application {

    static SharedPreferences sharedPreferences;
    static SharedPreferences.Editor editor;

    static SQLiteDatabase db;

    @Override
    public void onCreate() {
        super.onCreate();

        sharedPreferences = getSharedPreferences("wallpaper", MODE_PRIVATE);
        editor = sharedPreferences.edit();

        db = openOrCreateDatabase("my.db", MODE_PRIVATE, null);
        db.execSQL("create table if not exists fav(id integer primary key autoincrement,shyari text)");
    }

    public static void setcategory(String cat) {

        editor.putString("cat", cat).commit();

    }

    public static String getcategory() {
        return sharedPreferences.getString("cat", "");
    }



    public static void setimage(String image) {

        editor.putString("image", image).commit();
    }

    public static String getimage() {
        return sharedPreferences.getString("image", "");
    }


 public static void setpos(int pos) {

        editor.putInt("pos", pos).commit();
    }

    public static int getpos() {
        return sharedPreferences.getInt("pos", 0);
    }



    public static void setMylist(ArrayList<WallpaperItem> wallpaperItems) {
        Gson gson = new Gson();
        String arrayData = gson.toJson(wallpaperItems);

        editor.putString("list", arrayData).commit();


    }

    public static ArrayList<WallpaperItem> getMyList() {

        String data = sharedPreferences.getString("list", "");

        Gson gson = new Gson();

        ArrayList<WallpaperItem> wallpaerlist = (ArrayList<WallpaperItem>) gson.fromJson(data,
                new TypeToken<ArrayList<WallpaperItem>>() {
                }.getType());

        return wallpaerlist;

    }


}
