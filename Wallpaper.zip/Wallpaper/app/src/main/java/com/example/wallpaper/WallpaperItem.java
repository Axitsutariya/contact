package com.example.wallpaper;

public class WallpaperItem {

    String image;

    public WallpaperItem(String image) {
        this.image = image;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
