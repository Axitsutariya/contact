package com.example.wallpaper;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.bumptech.glide.Glide;

import java.util.ArrayList;


public class WallPaperAdapter extends RecyclerView.Adapter<WallPaperAdapter.Myh1> {

    ArrayList<WallpaperItem> wallpaperItems;
    Context context;
    Myclick myclick;

   public WallPaperAdapter(ArrayList<WallpaperItem> wallpaperItems ,Context context,Myclick myclick){

        this.wallpaperItems = wallpaperItems;
        this.myclick = myclick;
        this.context = context;
    }

    @NonNull
    @Override
    public WallPaperAdapter.Myh1 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view =LayoutInflater.from(context).inflate(R.layout.item_wallpaper,parent,false);

        return new Myh1(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WallPaperAdapter.Myh1 holder, int position) {

        Glide.with(context).load(wallpaperItems.get(position).getImage()).into(holder.iv);

        holder.iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myclick.getpos(position);

            }
        });

    }

    @Override
    public int getItemCount() {
        return wallpaperItems.size();
    }

    public class Myh1 extends RecyclerView.ViewHolder {

        ImageView iv;

        public Myh1(@NonNull View itemView) {
            super(itemView);

            iv =itemView.findViewById(R.id.iv);
        }
    }

    public interface Myclick{


        public void getpos(int pos);
    }


//
//    public WallPaperAdapter(ArrayList<WallpaperItem> wallpaperItems, Context context, Myclick myclick) {
//        this.wallpaperItems = wallpaperItems;
//        this.context = context;
//        this.myclick = myclick;
//    }
//
//    @NonNull
//    @Override
//    public Myh1 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//
//        View view1 =   LayoutInflater.from(context).inflate(R.layout.item_wallpaper,parent,false);
//        return new Myh1(view1);
//    }
//
//
//    @Override
//    public void onBindViewHolder(@NonNull Myh1 holder, @SuppressLint("RecyclerView") int position) {
//
//
//        Glide.with(context).load(wallpaperItems.get(position).getImage()).into(holder.iv);
//
//
//        holder.iv.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//              myclick.getpos(position);
//
//            }
//        });
//    }
//
//    @Override
//    public int getItemCount() {
//        return wallpaperItems.size();
//    }
//
//
//    public class Myh1 extends RecyclerView.ViewHolder {
//
//        ImageView iv;
//
//        public Myh1(@NonNull View itemView) {
//            super(itemView);
//
//            iv = itemView.findViewById(R.id.iv);
//
//        }
//    }
//
//    public interface Myclick {
//        public void getpos(int pos);
//    }


}