package com.example.wallpaper;

public class ShowItem {

    String showimage;

    public String getShowimage() {
        return showimage;
    }

    public void setShowimage(String showimage) {
        this.showimage = showimage;
    }

    public ShowItem(String showimage) {
        this.showimage = showimage;
    }
}
